from django.db.models.signals import post_save
from .models import Book
from django.dispatch import reciever
