window.onload = function() {
  cc_field = document.getElementById("id_cc_number");
  cc_field.setAttribute("placeholder", "4444 3333 2222 1111")

  phone_number_field = document.getElementById("id_phone_number")
  phone_number_field.setAttribute("placeholder", "+12125552368")

};
